package com.portfolio.gem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GemApplication {

	public static void main(String[] args) {
		SpringApplication.run(GemApplication.class, args);
	}

}
